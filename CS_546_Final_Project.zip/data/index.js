const itemsData = require("./items")
const commentsData = require("./comments")
const userData = require("./users")

module.exports = {
    items: itemsData,
    comments: commentsData,
    users: userData
}